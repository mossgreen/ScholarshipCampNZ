﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ICMVCJQuery.Models
{
    public class StaffData
    {
        public int staffId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

    }
}